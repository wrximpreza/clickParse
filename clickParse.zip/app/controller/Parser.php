<?php
/**
 * Ivan Dyachuk
 * Website: #
 * Social profiles
 * Email: wrximpreza1987@gmail.com
 * Copyright (c) 2016. All rights
 */
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

use \Curl\Curl;

/**
 * Class Parser
 */
class Parser
{

    /**
     * @var retunr object
     */
    private $output;
    /**
     * @var
     */
    public $lists;

    /**
     * @var
     */
    public $log;
    public $msg;
    /**
     * @var array can by contact page
     */
    public $contactUrl = array(
        '',
        '/contacts',
        '/contact'
    );


    /**
     * Parser constructor.
     */
    public function __construct()
    {
        $this->log = new Logger('parser');
        $this->log->pushHandler(new StreamHandler(_ROOT.'/logs/log.log', Logger::WARNING));

        $msg = new \Plasticbrain\FlashMessages\FlashMessages();

        $msg->setCssClassMap([
            $msg::INFO    => 'yellow',
            $msg::SUCCESS => 'green',
            $msg::WARNING => 'red',
            $msg::ERROR   => 'red',
        ]);

        $this->msg = $msg;

        $this->msg->setMsgWrapper("<div class=\"col s12 m8 offset-m2 l6 offset-l3\">
            <div class=\"card-panel  z-depth-1  %s\">
                <div class=\" valign-wrapper\">
                    <div class=\"col s12\">
                  <span class=\"black-text \">
                   %s
                  </span>
                    </div>
                </div>
            </div>
        </div>");
        $this->msg->setCloseBtn('');

    }

    /**
     * @param parserInterface $outputType
     */
    public function setOutput(parserInterface $outputType)
    {
        $this->output = $outputType;
    }

    /**
     * @return mixed
     */
    public function loadOutput()
    {
        $this->lists = $this->checkEmail($this->output->load());
        return $this->createExcel($this->lists);
    }

    /**
     * Create from array of emails xlsx files
     * @param data Array of emails
     * @return mixed link on the file
     */
    private function createExcel($data)
    {
        try {
            // Создаем объект класса PHPExcel
            $xls = new PHPExcel();
            // Устанавливаем индекс активного листа
            $xls->setActiveSheetIndex(0);
            // Получаем активный лист
            $sheet = $xls->getActiveSheet();
            $sheet->setTitle('Emails');
            $sheet->setCellValue("A1", 'URl');
            $sheet->getStyle('A1')->getAlignment()->setHorizontal(
                PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

            $sheet->setCellValue("B1", 'Title');
            $sheet->getStyle('B1')->getAlignment()->setHorizontal(
                PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

            $sheet->setCellValue("C1", 'Email');
            $sheet->getStyle('C1')->getAlignment()->setHorizontal(
                PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

            $sheet->setCellValue("D1", 'Status');
            $sheet->getStyle('D1')->getAlignment()->setHorizontal(
                PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

            $i = 1;
            foreach ($data as $item) {
                $sheet->setCellValueByColumnAndRow(
                    0,
                    $i,
                    $item['url']
                );
                $sheet->setCellValueByColumnAndRow(
                    1,
                    $i,
                    $item['title']
                );
                $sheet->setCellValueByColumnAndRow(
                    2,
                    $i,
                    $item['email']
                );
                $sheet->setCellValueByColumnAndRow(
                    3,
                    $i,
                    $item['status']
                );
                $i++;
            }
            $link = _ROOT . '/file/xls/' . uniqid('', true) . '_' . date('d.m.Y') . '.xlsx';

            $objWriter = PHPExcel_IOFactory::createWriter($xls, 'Excel2007');
            $objWriter->save($link);
            if (file_exists($link)) {
                return $link;
            }else{
                $this->log->error('Файл не создался');
                $this->msg->error('Файл не создался');
            }

        } catch (Exception $e) {
            $this->log->error('Message: '. $e->getMessage(). ', File: '. $e->getFile(). ', Line: '.$e->getLine());
        }
        return false;

    }

    /**
     * @param $urls Find emails from array links of pages
     * @return array Array emails from the links
     */
    private function checkEmail($urls)
    {
        $results = array();
        $status = 0;

        foreach ($urls as $url) {

            foreach ($this->contactUrl as $item) {

                $curl = new Curl();

                $curl->get(trim($url) . $item);
                $contentType = explode('=', $curl->responseHeaders['Content-Type']);

                if ($curl->error) {
                    $this->log->error('Error: url (' . trim($url) . $item . ') ' . $curl->errorCode . ': ' . $curl->errorMessage);
                    $this->msg->info('По ссылке '.trim($url) . $item.' нет email.');
                } else {

                    $emails = PhpMailExtractor::extract($curl->response);

                    if (count($emails) > 0) {

                        foreach ($emails as $email) {

                            if ($contentType[1] == 'UTF-8' || $contentType[1] == '')
                                $title = PhpMailExtractor::pageTitle($curl->response);
                            else
                                $title = iconv($contentType[1], 'UTF-8', PhpMailExtractor::pageTitle($curl->response));

                            $results[] = array(
                                'url' => $url,
                                'title' => $title,
                                'email' => $email,
                                'status' => 1
                            );
                            $this->msg->info('По ссылке '.trim($url) . $item.'  email есть - '.$email);

                        }
                        $status = 1;
                        break;
                    }else{
                        $this->msg->info('По ссылке '.trim($url) . $item.' нет email');
                    }

                }

                $curl->close();
            }

            if ($status === 0) {

                $results[] = array(
                    'url' => $url,
                    'title' => '',
                    'email' => 'Нет email',
                    'status' => 0
                );

            }

            $status = 0;
        }

        return $results;

    }

}