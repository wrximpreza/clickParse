<?php


/**
 * Interface parserInterface
 */
interface parserInterface
{
    /**
     * @return mixed
     */
    public function load();

}