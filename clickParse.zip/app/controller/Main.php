<?php

/**
 * Class Main
 */
class Main extends Parser
{
    /**
     * @var Request
     */
    public $input;

    /**
     * Main constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->input = new Request();
    }

    /**
     * Main page
     *
     */
    public function index()
    {

        $client = new Parser();

        if ($this->input->post('type')) {
            if (!$this->input->post('text')) {
                $message = 'Вы не ввели данные в форму';
                $this->msg->error('Вы не ввели данные в форму');
            } else {

                if ($this->input->post('type') == 'request') {
                    $client->setOutput(new urlFind($this->log, $this->msg, $this->input->post('text'), $this->input->post('count')));
                } else {
                    $client->setOutput(new fileFind($this->input->post('text')));
                }
                $link = $client->loadOutput();
                $lists = $client->lists;

                if ($link) {
                    $message = '<p>Файл успешно создан</p>';

                    $this->msg->success('Файл успешно создан');

                    $message = $message . $this->sendEmail($this->input->post('email'), $link);
                } else {
                    $message = '<p>Ошибка при создании файла</p>';
                    $this->msg->error('Ошибка при создании файла');
                    $this->log->error('Ошибка при создании файла');
                }

            }
        }



        include_once(_ROOT . '/app/view/index.php');
    }

    /**
     * @param $email
     * @param $link
     * @return string
     * @throws phpmailerException
     */
    public function sendEmail($email, $link)
    {
        $mail = new PHPMailer;

        //TODO change emails to right
        $mail->setFrom('from@localhost.com', 'Mailer');
        $mail->addAddress($email, 'User');
        $mail->addAddress($email);
        $mail->addReplyTo($email);
        // TODO chamge CC and BB
        $mail->addCC('cc@example.com');
        $mail->addBCC('bcc@example.com');

        $mail->addAttachment($link);
        $mail->isHTML(true);

        //TODO chamge sublect
        $mail->Subject = 'Письмо с сайта парсинга email';

        //TODO change email body
        $mail->Body = 'This is the HTML message body <b>in bold!</b>';
        try {
            if (!$mail->send()) {
                $this->log->error(' Ошибка отправки сообщения: ' . $mail->ErrorInfo);
                $this->msg->error(' Ошибка отправки сообщения: ' . $mail->ErrorInfo);
                return ' Ошибка отправки сообщения: ' . $mail->ErrorInfo;
            } else {
                $this->msg->success('<p>Сообщение успешно отправлено</p>');
                return 'Сообщение успешно отправлено';
            }
        } catch (Exception $e) {
            $this->log->error('Message: '. $e->getMessage(). ', File: '. $e->getFile(). ', Line: '.$e->getLine());
            $this->msg->error(' Ошибка отправки сообщения: ' . $e->getMessage());
            return ' Ошибка отправки сообщения: ' . $e->getMessage();
        }

    }

}